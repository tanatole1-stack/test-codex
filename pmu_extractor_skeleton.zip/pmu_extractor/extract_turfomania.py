from __future__ import annotations
import re
from typing import List, Tuple
import fitz  # PyMuPDF
from .models import CourseRow
from .diagnostics import Diagnostics
from .config import TM_STRUCTURED_A_HEADERS, TM_STRUCTURED_B_KEYS, TM_STRUCTURED_C_KEYS
from .quality import parse_int_tokens, validate_num_list

def is_structured_page(text: str) -> bool:
    t = text.upper()
    a = sum(1 for k in TM_STRUCTURED_A_HEADERS if k in t) >= 2
    b = any(k in t for k in TM_STRUCTURED_B_KEYS)
    c = any(k in t for k in TM_STRUCTURED_C_KEYS)
    return (a + b + c) >= 2

def parse_reunion_course(text: str) -> Tuple[str, str]:
    m = re.search(r"\(\s*R[ÉE]UNION\s*(\d+)\s*[-–]\s*Course\s*(\d+)\s*\)", text, flags=re.IGNORECASE)
    if m:
        return f"R{m.group(1)}", f"C{m.group(2)}"
    m2 = re.search(r"\bR(\d)\s*C(\d{1,2})\b", text, flags=re.IGNORECASE)
    if m2:
        return f"R{m2.group(1)}", f"C{m2.group(2)}"
    return "", ""

def parse_nom_prix(text: str) -> str:
    for ln in (ln.strip() for ln in text.splitlines()):
        if re.match(r"^PRIX\s+", ln, flags=re.IGNORECASE):
            return ln
    return ""

def parse_caracteristiques(text: str) -> str:
    for ln in (ln.strip() for ln in text.splitlines() if ln.strip()):
        if "MÈT" in ln.upper() or "METRES" in ln.upper():
            return ln
    return ""

def parse_partants(text: str) -> str:
    m = re.search(r"\b(\d{1,2})\s+partants\b", text, flags=re.IGNORECASE)
    return m.group(1) if m else ""

def parse_montant(text: str) -> str:
    m = re.search(r"(\d[\d\s\.]{2,})\s*(€|EUROS)", text, flags=re.IGNORECASE)
    if not m:
        return ""
    val = m.group(1).replace(" ", "").replace(".", "")
    return f"{val}€"

def _block(text: str, anchor: str, max_lines: int = 10) -> str:
    lines = text.splitlines()
    for i, ln in enumerate(lines):
        if anchor.upper() in ln.upper():
            return "\n".join(lines[i:i+max_lines])
    return ""

def parse_pronostic(text: str) -> List[str]:
    blk = _block(text, "PRONOSTIC DE TURFOMANIA", 8)
    nums = parse_int_tokens(blk)
    if len(nums) > 12:
        nums = nums[:8]
    ok, _ = validate_num_list(nums) if nums else (False, "EMPTY")
    return nums if ok else []

def parse_base(text: str) -> str:
    m = re.search(r"BASE\s*:\s*(\d{1,2})\b", text, flags=re.IGNORECASE)
    return m.group(1) if m else ""

def parse_trouble_fete(text: str) -> str:
    m = re.search(r"TROUBLE\s*[-–]?\s*F[ÊE]TE\s*:?\s*(\d{1,2})\b", text, flags=re.IGNORECASE)
    return m.group(1) if m else ""

def parse_scan(text: str) -> List[str]:
    blk = _block(text, "SCAN PREMIUM", 10)
    nums = parse_int_tokens(blk)
    if len(nums) > 14:
        nums = nums[:8]
    ok, _ = validate_num_list(nums) if nums else (False, "EMPTY")
    return nums if ok else []

def extract_turfomania(pdf_path: str, reunions_to_keep: List[str], diag: Diagnostics, strict: bool = True) -> List[CourseRow]:
    doc = fitz.open(pdf_path)
    structured = []
    for pno in range(doc.page_count):
        txt = doc.load_page(pno).get_text("text")
        if is_structured_page(txt):
            structured.append(pno)

    rows: List[CourseRow] = []
    for pno in structured:
        txt = doc.load_page(pno).get_text("text")
        r, c = parse_reunion_course(txt)
        nom = parse_nom_prix(txt)

        if r and reunions_to_keep and r not in reunions_to_keep:
            continue
        if strict and not r:
            diag.add(r, c, nom, "PHASE1", "TM_NO_REUNION", f"Page {pno+1}: Reunion not found (strict skip)")
            continue

        row = CourseRow(
            reunion=r,
            course=c,
            nom_prix=nom,
            caracteristiques=parse_caracteristiques(txt),
            partants=parse_partants(txt),
            montant=parse_montant(txt),
        )
        row.tm_p = parse_pronostic(txt)
        if not row.tm_p:
            diag.add(r, c, nom, "PHASE1", "TM_P_EMPTY", f"Page {pno+1}: Pronostic not parsed")
        row.tm_b = parse_base(txt)
        if not row.tm_b:
            diag.add(r, c, nom, "PHASE1", "TM_BASE_EMPTY", f"Page {pno+1}: BASE not found")
        row.tm_t = parse_trouble_fete(txt)
        row.tm_scan = parse_scan(txt)
        if not row.tm_scan:
            diag.add(r, c, nom, "PHASE1", "TM_SCAN_EMPTY", f"Page {pno+1}: SCAN not parsed")

        rows.append(row)

    return rows
